<?php $__env->startSection('content'); ?>
    <?php
        $structure = [
            'root' => [
                'name' => 'SRI NISMALA DEWI, SKM',
                'nip' => '19770725 200312 2 009',
                'role' => 'KEPALA UPT PPA',
            ],
            'middle' => [
                [
                    'type' => 'fungsional',
                    'role' => 'KELOMPOK JABATAN FUNGSIONAL',
                    'desc' => 'Tim Profesi & Konselor',
                    'children' => []
                ],
                [
                    'type' => 'kasubag',
                    'role' => 'KEPALA SUB BAGIAN TATA USAHA',
                    'name' => 'KATERINA SUSANTI, SKM, M.Kes',
                    'nip' => '19750620 200003 2 005',
                    'children' => [
                        ['role' => 'PENGOLAH DATA DAN INFORMASI'],
                        ['role' => 'PENGADMINISTRASI PERKANTORAN'],
                        ['role' => 'PENGADMINISTRASI PERKANTORAN', 'name' => 'MASNIARTI', 'nip' => '19770514 200801 2 022'],
                        ['role' => 'OPERATOR LAYANAN OPERASIONAL', 'name' => 'Jefrizon'],
                        ['role' => 'OPERATOR LAYANAN OPERASIONAL', 'name' => 'Yogi Yogasuara'],
                        ['role' => 'OPERATOR LAYANAN OPERASIONAL', 'name' => 'Habibul Akmal'],
                    ]
                ]
            ],
            'bottom' => [
                [
                    'role' => 'KEPALA SEKSI PENGADUAN',
                    'name' => 'HENDRI SAMANTHA, S.IP, M.AP',
                    'nip' => '19880406 200701 1 004',
                    'children' => [
                         ['role' => 'PENATA KELOLA PEMBERDAYAAN PEREMPUAN DAN PERLINDUNGAN ANAK', 'name' => 'JUWITA, S.Sos', 'nip' => '19690710 199003 2 004'],
                         ['role' => 'PENATA KELOLA PEMBERDAYAAN PEREMPUAN DAN PERLINDUNGAN ANAK', 'name' => 'ETTY HERWATI, S.Sos', 'nip' => '19701127 200701 2 003'],
                         ['role' => 'PENATA KELOLA PEMBERDAYAAN PEREMPUAN DAN PERLINDUNGAN ANAK', 'name' => 'RUSNILAWATI, S.Sos', 'nip' => '19720420 199403 2 001'],
                    ]
                ],
                [
                    'role' => 'KEPALA SEKSI TINDAK LANJUT',
                    'name' => 'IIN RAFIDA, S.Psi, MM',
                    'nip' => '19810309 201102 2 001',
                    'children' => [
                         ['role' => 'PENATA KELOLA PEMBERDAYAAN PEREMPUAN DAN PERLINDUNGAN ANAK', 'name' => 'RAJA ZALIA GUSTIANA, S.Psi', 'nip' => '19880819 201503 2 004'],
                         ['role' => 'PENATA KELOLA PEMBERDAYAAN PEREMPUAN DAN PERLINDUNGAN ANAK', 'name' => 'WENI SAFITRI ISMAIL, S.H', 'nip' => '19930322 202203 2 008'],
                         ['role' => 'PENATA KELOLA PEMBERDAYAAN PEREMPUAN DAN PERLINDUNGAN ANAK', 'name' => 'PUTRI NOVI DUWINDI, S.H', 'nip' => '19941112 202203 2 005'],
                    ]
                ]
            ]
        ];
    ?>

    <div class="container mx-auto px-6 md:px-12 py-12">
        <div class="grid grid-cols-1 lg:grid-cols-4 gap-12">
            <!-- Main Content (Left Column) -->
            <div class="lg:col-span-3">
                <h1 class="text-3xl md:text-4xl font-black text-primary mb-8 pb-4 border-b-2 border-slate-200 uppercase tracking-tight">
                    STRUKTUR ORGANISASI
                </h1>
                
                <!-- Desktop Tree View -->
                <div class="hidden md:block overflow-x-auto pb-12">
                    <div class="min-w-[900px] flex flex-col items-center">
                        
                        <!-- Level 1: Kepala UPT -->
                        <div class="flex flex-col items-center mb-12 relative z-10">
                            <div class="w-64 bg-white dark:bg-slate-800 border-2 border-primary/20 p-5 text-center rounded-lg relative z-20 hover:border-primary transition-colors duration-300">
                                <div class="w-16 h-16 bg-primary/5 mx-auto rounded-full mb-3 flex items-center justify-center overflow-hidden">
                                     <span class="material-icons text-primary text-3xl">person</span>
                                </div>
                                <h4 class="font-bold text-primary uppercase text-xs tracking-wider mb-1"><?php echo e($structure['root']['role']); ?></h4>
                                <p class="text-sm font-bold text-slate-800 dark:text-slate-200"><?php echo e($structure['root']['name']); ?></p>
                                <p class="text-[10px] text-slate-400 mt-1 uppercase tracking-wide">NIP. <?php echo e($structure['root']['nip']); ?></p>
                            </div>
                            <!-- Vertical Line Down -->
                            <div class="h-10 w-px bg-slate-300 absolute -bottom-10 left-1/2 transform -translate-x-1/2"></div>
                        </div>

                        <!-- Connector Line Horizontal for Level 2 -->
                        <div class="w-[60%] h-8 border-t border-l border-r border-slate-300 rounded-t-xl mb-4 relative">
                            <div class="absolute -top-4 left-1/2 h-4 w-px bg-slate-300 transform -translate-x-1/2"></div>
                        </div>

                        <!-- Level 2: Middle Management -->
                        <div class="flex justify-center gap-6 w-full items-start mb-12">
                            <?php $__currentLoopData = $structure['middle']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $node): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex flex-col items-center relative w-1/3">
                                    <!-- Vertical Line Up -->
                                    <div class="h-4 w-px bg-slate-300 absolute -top-4 left-1/2 transform -translate-x-1/2"></div>
                                    
                                    <div class="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-4 text-center rounded-lg mb-4 hover:shadow-md transition-shadow duration-300">
                                        <h4 class="font-bold text-slate-700 dark:text-slate-300 uppercase text-[10px] tracking-wider mb-1"><?php echo e($node['role']); ?></h4>
                                        <?php if(isset($node['name'])): ?>
                                            <p class="text-xs font-bold text-slate-900 dark:text-white"><?php echo e($node['name']); ?></p>
                                            <p class="text-[10px] text-slate-400 mt-0.5">NIP. <?php echo e($node['nip']); ?></p>
                                        <?php elseif(isset($node['desc'])): ?>
                                            <p class="text-xs text-slate-500 italic"><?php echo e($node['desc']); ?></p>
                                        <?php endif; ?>
                                    </div>

                                    <!-- Children for Level 2 -->
                                    <?php if(isset($node['children']) && count($node['children']) > 0): ?>
                                        <div class="space-y-2 w-full px-4">
                                            <?php $__currentLoopData = $node['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="bg-gray-50 dark:bg-slate-900/50 border-l-2 border-slate-300 p-2 pl-3 text-left relative">
                                                     <p class="text-[10px] font-bold text-slate-600 dark:text-slate-400 uppercase"><?php echo e($child['role']); ?></p>
                                                     <?php if(isset($child['name'])): ?>
                                                        <p class="text-[10px] text-slate-500 truncate"><?php echo e($child['name']); ?></p>
                                                     <?php endif; ?>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                         <!-- Connector Line Horizontal for Level 3 -->
                         <div class="w-[70%] h-8 border-t border-l border-r border-slate-300 rounded-t-xl mb-4 relative opacity-50">
                             <!-- This connector is visually just to group them, theoretically they connect to head but visual balance is key -->
                            <div class="absolute -top-24 left-1/2 h-24 w-px bg-slate-300 transform -translate-x-1/2 -z-10"></div>
                        </div>

                        <!-- Level 3: Sections (Kasi) -->
                        <div class="flex justify-center gap-10 w-full items-start">
                             <?php $__currentLoopData = $structure['bottom']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $node): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex flex-col items-center relative w-1/2 max-w-sm">
                                    <!-- Vertical Line Up -->
                                    <div class="h-4 w-px bg-slate-300 absolute -top-4 left-1/2 transform -translate-x-1/2"></div>
                                    
                                    <div class="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-4 text-center rounded-lg mb-4 hover:border-slate-400 transition-colors">
                                        <h4 class="font-bold text-slate-700 dark:text-slate-300 uppercase text-[10px] tracking-wider mb-1"><?php echo e($node['role']); ?></h4>
                                        <p class="text-sm font-bold text-slate-900 dark:text-white"><?php echo e($node['name']); ?></p>
                                        <p class="text-[10px] text-slate-400 mt-0.5">NIP. <?php echo e($node['nip']); ?></p>
                                    </div>

                                    <!-- Children (Staff) -->
                                     <div class="w-full space-y-3 relative pl-6">
                                         <!-- Vertical line connecting children -->
                                         <div class="absolute top-0 bottom-6 left-2 w-px bg-slate-200"></div>

                                        <?php $__currentLoopData = $node['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="relative pl-4">
                                                <!-- Horizontal connector -->
                                                <div class="absolute top-2.5 left-[-16px] w-4 h-px bg-slate-200"></div>

                                                <div class="bg-transparent">
                                                     <p class="text-[10px] font-semibold text-slate-500 uppercase tracking-wide leading-tight mb-0.5"><?php echo e($child['role']); ?></p>
                                                     <p class="text-xs font-bold text-slate-800 dark:text-slate-200"><?php echo e($child['name']); ?></p>
                                                     <?php if(isset($child['nip'])): ?>
                                                        <p class="text-[10px] text-slate-400">NIP. <?php echo e($child['nip']); ?></p>
                                                     <?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                </div>

                <!-- Mobile Accordion View -->
                <div class="md:hidden space-y-2" x-data="{ active: null }">
                    <!-- Root -->
                    <div class="bg-white dark:bg-slate-800 border-b border-slate-100 dark:border-slate-700 pb-2 mb-4">
                        <div class="flex items-center gap-3 py-2">
                             <div class="w-12 h-12 rounded-full bg-primary/5 flex items-center justify-center text-primary shrink-0">
                                <span class="material-icons text-2xl">person</span>
                            </div>
                            <div>
                                <h4 class="font-bold text-primary text-xs uppercase tracking-wider mb-0.5"><?php echo e($structure['root']['role']); ?></h4>
                                <p class="text-sm font-bold text-slate-800 dark:text-slate-200"><?php echo e($structure['root']['name']); ?></p>
                                <p class="text-[10px] text-slate-400 mt-0.5">NIP. <?php echo e($structure['root']['nip']); ?></p>
                            </div>
                        </div>
                    </div>

                    <!-- Middle Level -->
                    <?php $__currentLoopData = $structure['middle']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $node): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="border border-slate-100 dark:border-slate-700 rounded-lg overflow-hidden">
                             <button @click="active = (active === 'mid-<?php echo e($index); ?>' ? null : 'mid-<?php echo e($index); ?>')" class="w-full text-left px-4 py-3 flex items-center justify-between bg-slate-50 dark:bg-slate-900 hover:bg-slate-100 transition-colors">
                                <div class="flex items-center gap-3">
                                    <span class="material-icons text-slate-400 text-lg">
                                        <?php echo e($node['type'] === 'fungsional' ? 'groups' : ($node['type'] === 'kasubag' ? 'admin_panel_settings' : 'support_agent')); ?>

                                    </span>
                                    <div>
                                        <h4 class="font-semibold text-slate-700 dark:text-slate-300 text-xs uppercase tracking-wide"><?php echo e($node['role']); ?></h4>
                                        <?php if(isset($node['name'])): ?>
                                            <p class="text-[10px] text-slate-500"><?php echo e($node['name']); ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <span class="material-icons text-slate-300 text-sm transition-transform duration-300" :class="active === 'mid-<?php echo e($index); ?>' ? 'rotate-180' : ''">expand_more</span>
                            </button>
                            <?php if(isset($node['children']) && count($node['children']) > 0): ?>
                                <div x-show="active === 'mid-<?php echo e($index); ?>'" x-collapse class="bg-white dark:bg-slate-800 p-3 space-y-3">
                                    <?php $__currentLoopData = $node['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="pl-8 text-xs">
                                            <p class="font-bold text-slate-600 dark:text-slate-400"><?php echo e($child['role']); ?></p>
                                            <?php if(isset($child['name'])): ?>
                                                <p class="text-[10px] text-slate-400"><?php echo e($child['name']); ?></p>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- Bottom Level (Seksi) -->
                     <?php $__currentLoopData = $structure['bottom']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $node): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="border border-slate-100 dark:border-slate-700 rounded-lg overflow-hidden">
                             <button @click="active = (active === 'bot-<?php echo e($index); ?>' ? null : 'bot-<?php echo e($index); ?>')" class="w-full text-left px-4 py-3 flex items-center justify-between bg-slate-50 dark:bg-slate-900 hover:bg-slate-100 transition-colors">
                                <div class="flex items-center gap-3">
                                    <span class="material-icons text-slate-400 text-lg">assignment_ind</span>
                                    <div>
                                        <h4 class="font-semibold text-slate-700 dark:text-slate-300 text-xs uppercase tracking-wide"><?php echo e($node['role']); ?></h4>
                                        <p class="text-[10px] text-slate-500"><?php echo e($node['name']); ?></p>
                                    </div>
                                </div>
                                <span class="material-icons text-slate-300 text-sm transition-transform duration-300" :class="active === 'bot-<?php echo e($index); ?>' ? 'rotate-180' : ''">expand_more</span>
                            </button>
                            <?php if(isset($node['children']) && count($node['children']) > 0): ?>
                                <div x-show="active === 'bot-<?php echo e($index); ?>'" x-collapse class="bg-white dark:bg-slate-800 p-3 space-y-4">
                                    <?php $__currentLoopData = $node['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="pl-8 relative">
                                            <div class="absolute left-3 top-1.5 w-1.5 h-1.5 rounded-full bg-slate-200"></div>
                                            <p class="text-[10px] text-slate-400 uppercase tracking-wider mb-0.5"><?php echo e($child['role']); ?></p>
                                            <p class="text-xs font-bold text-slate-700 dark:text-slate-300"><?php echo e($child['name']); ?></p>
                                            <?php if(isset($child['nip'])): ?>
                                                <p class="text-[10px] text-slate-400">NIP. <?php echo e($child['nip']); ?></p>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                
                 <!-- Riau Legal Footer -->
                <div class="mt-12 pt-6 border-t border-slate-200 dark:border-slate-700 text-center">
                    <p class="text-xs font-bold text-slate-500 uppercase tracking-wide">Dasar: Pergub Riau Nomor 85 Tahun 2019</p>
                </div>

            </div>

            <!-- Sidebar (Right Column) -->
            <div class="lg:col-span-1">
                <?php echo $__env->make('components.public.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/ryanda/project/uptppa/resources/views/public/profile/struktur.blade.php ENDPATH**/ ?>