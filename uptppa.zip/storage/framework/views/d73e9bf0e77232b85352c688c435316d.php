<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-6 md:px-12 py-12">
        <div class="grid grid-cols-1 lg:grid-cols-4 gap-12">
            <!-- Main Content (Left Column) -->
            <div class="lg:col-span-3">
                <h1 class="text-xl font-bold text-slate-700 dark:text-white mb-8 pb-2 border-b-4 border-primary uppercase">
                    ARTIKEL
                </h1>
                
                <div class="space-y-8">
                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Article Item -->
                    <div class="bg-white dark:bg-slate-800">
                        <a href="<?php echo e(route('public.publications.articles.show', $item->slug)); ?>" class="block text-primary hover:underline text-lg font-bold mb-4">
                            <?php echo e($item->title); ?>

                        </a>
                        <div class="flex flex-col md:flex-row gap-6">
                            <img src="<?php echo e($item->image); ?>" alt="Article Thumbnail" class="w-full md:w-48 h-32 object-cover flex-shrink-0">
                            <div class="flex-grow">
                                <div class="text-sm text-slate-600 dark:text-slate-300 text-justify leading-relaxed mb-4">
                                    <?php echo Str::limit(strip_tags($item->content), 200); ?>

                                </div>
                            </div>
                        </div>
                        <div class="flex justify-between items-center mt-2 pt-2 border-t border-dotted border-slate-300">
                            <span class="text-xs text-slate-500"><?php echo e($item->published_at->format('Y/m/d H:i:s')); ?></span>
                            <a href="<?php echo e(route('public.publications.articles.show', $item->slug)); ?>" class="text-xs px-3 py-1 border border-slate-300 text-slate-600 hover:bg-slate-100 transition rounded-sm">Baca</a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- Pagination -->
                    <div class="mt-8">
                        <?php echo e($articles->links()); ?>

                    </div>
                </div>

            </div>

             <!-- Sidebar (Right Column) -->
             <div class="lg:col-span-1">
                <?php echo $__env->make('components.public.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/ryanda/project/uptppa/resources/views/public/publications/articles.blade.php ENDPATH**/ ?>